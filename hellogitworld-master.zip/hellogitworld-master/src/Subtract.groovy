static int subtract(int val1, val2) {
    val1 - val2
}