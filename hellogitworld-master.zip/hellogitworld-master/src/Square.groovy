static int square(int base) {
	base * base
}