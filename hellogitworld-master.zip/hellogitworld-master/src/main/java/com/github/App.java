package com.github;

/**
 * Hello again
 * Hello world!
 * Hello
 */
public class App 
{
    public static void main( String[] args )
    {
    	//Comment
        System.out.println( "Hello World!" );
    }
}

//foo
